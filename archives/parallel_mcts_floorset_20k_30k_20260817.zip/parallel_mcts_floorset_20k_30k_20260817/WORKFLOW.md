# 20K/30K Parallel-MCTS + FloorSet Final Archive

## Scope

This archive freezes the final 20K/30K R60/R95 benchmark outputs and the complete implementation workflow at source commit `7944864` on branch `codex/parallel-mcts-floorset-benchmark`.

## Reproduction command

```powershell
python -m floorset_benchmark.mcts_tree_depth_suite `
  --source-dir outputs/floorset_day2/config_21_torch `
  --output-root outputs/floorset_mcts_tree_depth_calibrated/bulk `
  --targets 20000 30000 `
  --reuse-rates 0.60 0.95
```

Use the repository's Python environment with PyTorch available. Each case stores the derived hierarchy/reuse/topology/tree-profile/width seeds in `manifest.json`.

## End-to-end flow

1. Load the converted FloorSet source sample (`floorset_config21_1`). FloorSet connectivity weight is an ordering/distribution prior, not physical Pin width.
2. Compose a fixed hierarchy of 12 parents and 228 leaves (240 non-root instances); normalize reused type geometry across rotations/mirrors without scaling.
3. Generate independent hierarchical nets and cross-Net homology templates. A homology group may link different counterpart groups across multiple Nets, while every full Pin belongs to exactly one Net.
4. Calibrate width/pressure with the existing capacity-aware FloorSet-first mapper. Capacity is deducted once per homology group, not once per instance Pin or related Net.
5. Validate hierarchy containment, overlap, successor DAGs, reuse geometry, exact PinGroup count, segment packing, and hard overflow.
6. Load through PlaceDB, HomologyManager, SegmentManager and BatchPlanner integration paths.
7. Reconstruct runtime MCTS trees with the formal AssignmentSolver configuration and separately report static, ordered, effective, component and batch depths.
8. Run assignment correctness smoke, require complete assignments, zero capacity violations, and acceptance of every case.

## Frozen case profiles

- 20K: capacity pressure mix 75% small / 20% normal / 5% large.
- 30K: capacity pressure mix 80% small / 19% normal / 1% large.
- R60: exactly 144 reused non-root instances, deterministic mixed cluster strategy (2-10 instances).
- R95: exactly 228 reused non-root instances, deterministic reuse construction.
- Tree-profile group budget fraction: 0.60.
- Target effective-depth distribution: depth 2-10 is dominant; 11-20 and 21-100 are non-zero; depth >100 is zero.

## Final results

| Case | PinGroups | Trees | P50 | P90 | P95 | P99 | Max | 2-10 | 11-20 | 21-100 | >100 | Unassigned | Rejected | Overflow |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 20k_r60 | 20000 | 4453 | 3 | 10 | 15 | 31 | 64 | 85.38% | 6.85% | 1.37% | 0 | 0 | 0 | 0 |
| 20k_r95 | 20000 | 4453 | 3 | 10 | 15 | 31 | 64 | 85.38% | 6.85% | 1.37% | 0 | 0 | 0 | 0 |
| 30k_r60 | 30000 | 6761 | 2 | 10 | 15 | 31 | 64 | 85.59% | 6.74% | 1.35% | 0 | 0 | 0 | 0 |
| 30k_r95 | 30000 | 6761 | 2 | 10 | 15 | 31 | 64 | 85.59% | 6.74% | 1.35% | 0 | 0 | 0 | 0 |

All four cases are accepted. The complete repository test result for the frozen implementation is `84 passed in 3.12s`.

## Archive layout

- `results/<case>/`: 17 final artifacts per case, including block/pingroup data, lineage, validation, capacity, MCTS-depth, batch-vs-runtime, assignment smoke and statistics.
- `workflow/source_snapshot_7944864.zip`: complete tracked repository source at the frozen commit, including implementation, tests and planning/research documentation.
- `aggregate_summary.json`: machine-readable four-case summary.
- `SHA256SUMS.txt`: SHA-256 for every archived payload file except the checksum file itself.

## Reference-data note

`case3.xlsx` was used only as a partial conditional prior for small/medium runtime MCTS-tree depths. It is not treated as a full-case distribution and is not bundled because it is an external desktop input, not a generated benchmark artifact.

## PlaceDB layout rendering

The four cases are loaded with `PlaceDB(block_json_path, pingroup_json_path)` and rendered from `PlaceDB.all_modules_list`, `root_module`, `Module.children`, `Module.vertex`, and `Module.get_hierarchy_level()`. The output is not a detached JSON sketch.

Run:

```powershell
python floorset_benchmark/plot_placedb_blocks.py
```

Each `results/<case>/plots/` directory contains `block_layout.png` (2200x1400) and `plot_report.json`. Validation for every case is 241 total modules = 1 root + 12 parents + 228 leaves (240 non-root instances).
